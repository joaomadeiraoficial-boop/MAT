# Índice Têmporis — reprodução da Base A

Pacote parcial extraído de `MAT_Refinado_0_1.zip`, com o snapshot JSON original de 07/11/2026 (800 candidatos; 667 elegíveis). Não é a aplicação MAT completa. Os módulos PHP foram copiados sem alterações.

## Teste retrospectivo

Requer PHP 8.x CLI. Na raiz deste diretório, execute:

```sh
php tests/test_previsoes_50_anos_snapshot.php
```

O teste verifica três cortes individuais e o WAPE dos 12 cortes do modelo exponencial de 50 anos, na ponderação quadrática. Não necessita de MySQL nem de serviços de IA. Não valida independentemente todos os resultados do artigo nem a qualidade historiográfica das notas.

SHA-256 do JSON: 47fa301738ae5d43569286e6da7af7eaee1bbe34f8c22144dcffb8d87690843b.

Antes de tornar público, confira a autorização para compartilhar os registros, fontes e justificativas. O dump SQL integral e a configuração local não estão neste pacote.
